classdef herm < CGLE.basic
    % CGinzburgLandauEq Class for representing the complex Ginzburg Landau
    % equation
    % The complex Ginzburg-Landau equation needs to know its:
    % U: convection constant
    % cu: most unstable wavenumber
    % cd: dispersion
    % mu0: control paramter
    % mu2: non-parallel parameter
    % nx: number of spatial points
    % L: linear scaling factor
    % scaling: scaling type: chose {'linear','fraction','atan','asin'}
    
    %%   Properties
    properties
        %% Discretisation
        nx
    end
    %% Dependent properties
    properties (Dependent, Access = public)
        %% Discretised System terms
        xh
        D1
        D2
        xgrid
        Q
        %% Result
        mux
        A 
    end
    %% Extra Hermite terms
    properties (Dependent, Access = protected)
        DM
    end
    %% Methods
    methods
        %% Setup function - default overwrite
        function thisCGLE = herm(Setup)
            if nargin == 1
                if strcmp(Setup,'SupCrit')
                    thisCGLE.U = 2;
                    thisCGLE.cu = 0.2;
                    thisCGLE.cd = -1.0;
                    thisCGLE.mu0 = 0.41;
                    thisCGLE.mu2 = -0.01;
                    thisCGLE.nx = 200;
                end
            end
        end
        %% Identify
        function identify(thisCGLE)
            disp(['I am a complex Ginzburg-Landau system discretised with nx = ',num2str(thisCGLE.nx),' hermite points'])
        end
        %% Get DM
        function DM = get.DM(theCGLE)
            DM = herdif(theCGLE.xh,2,real(theCGLE.chi));
        end        
        %% Get xh
        function xh = get.xh(theCGLE)
            xh = herroots(theCGLE.nx);
        end
        %% Get D1
        function D1 = get.D1(theCGLE)
            D1 = theCGLE.DM(:,:,1);
        end
        %% Get D2
        function D2 = get.D2(theCGLE)
            D2 = theCGLE.DM(:,:,2);
        end
        %% Get xgrid
        function xgrid = get.xgrid(theCGLE)
            xgrid = theCGLE.xh / real(theCGLE.chi);
        end
        %% Get Q (diag(w))
        function Q = get.Q(theCGLE)
            Q = diag( ([ diff(theCGLE.xgrid); 0 ] + [ 0; diff(theCGLE.xgrid) ]) / 2 ); % Trapezoidal rule
        end
        %% Get mux
        function mux = get.mux(theCGLE)
            mux = theCGLE.mu0 - real( theCGLE.gam ) * theCGLE.cu ^ 2 + theCGLE.mu2 * ( theCGLE.xgrid ) .^ 2 / 2 ;
        end
        %% Get A
        function A = get.A(theCGLE)
            A = - theCGLE.nu * theCGLE.D1 + theCGLE.gam * theCGLE.D2 + diag( theCGLE.mux );
            A = [real(A), imag(A); -imag(A), real(A)]; % Augment to real system
        end        
        %% Restrict nx
        function theCGLE = set.nx(theCGLE,nx)
            if nx > 0 && nx < 248
                theCGLE.nx = nx;
            else
                error('nx must be: 248 > nx > 0')
            end
        end        
    end
end

function r = herroots(N)

%  The function r = herroots(N) computes the roots of the
%  Hermite polynomial of degree N.

%  J.A.C. Weideman, S.C. Reddy 1998.

J = diag(sqrt([1:N-1]),1)+diag(sqrt([1:N-1]),-1);    % Jacobi matrix
r = sort(eig(sparse(J)))/sqrt(2);                    % Compute eigenvalues
end
%%
function DM = herdif(x, M, b)
%  based on: J.A.C. Weideman, S.C. Reddy 1998


alpha = exp(-x.^2/2);                 % Compute weights.

beta(1,:) = ones(size(x'));           % Set up beta matrix s.t. beta(l,j) =
beta(2,:) = -x';                      % (l-th derivative of alpha(x))/alpha(x), evaluated at x = x(j).

for ell = 3:M+1
    beta(ell,:) = -x'.*beta(ell-1,:)-(ell-2)*beta(ell-2,:);
end

beta(1,:) = [];                       % Remove initializing row from beta

DM = poldif(x, alpha, beta);          % Compute differentiation matrix (b=1).

for ell = 1:M                         % Adjust for b not equal to 1.
    DM(:,:,ell) = (b^ell)*DM(:,:,ell);
end
end

%%

function DM = poldif(x, malpha, B)

%  The function DM =  poldif(x, maplha, B) computes the
%  differentiation matrices D1, D2, ..., DM on arbitrary nodes.
%
%  The function is called with either two or three input arguments.
%  If two input arguments are supplied, the weight function is assumed
%  to be constant.   If three arguments are supplied, the weights should
%  be defined as the second and third arguments.
%
%  Input (constant weight):
%
%  x:        Vector of N distinct nodes.
%  malpha:   M, the number of derivatives required (integer).
%  B:        Omitted.
%
%  Note:     0 < M < N-1.
%
%  Input (non-constant weight):
%
%  x:        Vector of N distinct nodes.
%  malpha:   Vector of weight values alpha(x), evaluated at x = x(k).
%  B:        Matrix of size M x N,  where M is the highest
%            derivative required.  It should contain the quantities
%            B(ell,j) = beta(ell,j) = (ell-th derivative
%            of alpha(x))/alpha(x),   evaluated at x = x(j).
%
%  Output:
%  DM:       DM(1:N,1:N,ell) contains ell-th derivative matrix, ell=1..M.

%  J.A.C. Weideman, S.C. Reddy 1998

N = length(x);
x = x(:);                     % Make sure x is a column vector

if nargin == 2                       % Check if constant weight function
    M = malpha;                   % is to be assumed.
    alpha = ones(N,1);
    B = zeros(M,N);
elseif nargin == 3
    alpha = malpha(:);                % Make sure alpha is a column vector
    M = length(B(:,1));           % First dimension of B is the number
end                                  % of derivative matrices to be computed

I = eye(N);                  % Identity matrix.
L = logical(I);              % Logical identity matrix.

XX = x(:,ones(1,N));
DX = XX-XX';                  % DX contains entries x(k)-x(j).

DX(L) = ones(N,1);               % Put 1's one the main diagonal.

c = alpha.*prod(DX,2);       % Quantities c(j).

C = c(:,ones(1,N));
C = C./C';                   % Matrix with entries c(k)/c(j).

Z = 1./DX;                   % Z contains entries 1/(x(k)-x(j))
Z(L) = zeros(N,1);              % with zeros on the diagonal.

X = Z';                      % X is same as Z', but with
X(L) = [];                      % diagonal entries removed.
X = reshape(X,N-1,N);

Y = ones(N-1,N);             % Initialize Y and D matrices.
D = eye(N);                  % Y is matrix of cumulative sums,
% D differentiation matrices.
for ell = 1:M
    Y   = cumsum([B(ell,:); ell*Y(1:N-1,:).*X]); % Diagonals
    D   = ell*Z.*(C.*repmat(diag(D),1,N) - D);   % Off-diagonals
    D(L)   = Y(N,:);                                % Correct the diagonal
    DM(:,:,ell) = D;                                     % Store the current D
end

end