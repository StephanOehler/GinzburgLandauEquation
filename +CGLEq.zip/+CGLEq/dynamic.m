classdef dynamic < CGLEq.spectral
    %CGLE_HERM_DYNAMIC Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        x_a
        x_s
        var_a
        var_s
        R = 1/49
        beta = 1
        Vp05 = (2*1e-4)
    end
    
    properties (Dependent, Access = public)
        B
        C
        GammaOE
        GammaFI
        GammaIO
    end
    
    properties (Dependent)
        P % DynamicSys
    end
    
    methods
        %% Setup function - default overwrite
        function thisCGLE = dynamic(Setup)
            if nargin == 1
                if strcmp(Setup,'SubCrit')
                    thisCGLE.U = 2;
                    thisCGLE.cu = 0.2;
                    thisCGLE.cd = -1.0;
                    thisCGLE.mu0 = 0.38;
                    thisCGLE.mu2 = -0.01;
                    thisCGLE.nx = 150;
                    thisCGLE.L = 20;
                    thisCGLE.scaling = 'linear';
                    %%% Actuator and Sensor
                    thisCGLE.x_a = -1;
                    thisCGLE.var_a = 0.4 * sqrt(2);
                    thisCGLE.x_s = -thisCGLE.x_a;
                    thisCGLE.var_s = thisCGLE.var_a;
                end
                if strcmp(Setup,'SupCrit')
                    thisCGLE.U = 2;
                    thisCGLE.cu = 0.2;
                    thisCGLE.cd = -1.0;
                    thisCGLE.mu0 = 0.41;
                    thisCGLE.mu2 = -0.01;
                    thisCGLE.nx = 150;
                    thisCGLE.L = 20;
                    thisCGLE.scaling = 'linear';
                    %%% Actuator and Sensor
                    thisCGLE.x_a = -1;
                    thisCGLE.var_a = 0.4 * sqrt(2);
                    thisCGLE.x_s = -thisCGLE.x_a;
                    thisCGLE.var_s = thisCGLE.var_a;
                end
                if strcmp(Setup,'Stable')
                    thisCGLE.U = 2;
                    thisCGLE.cu = 0.2;
                    thisCGLE.cd = -1.0;
                    thisCGLE.mu0 = 0.41;
                    thisCGLE.mu2 = -0.01;
                    thisCGLE.nx = 150;
                    thisCGLE.L = 20;
                    thisCGLE.scaling = 'linear';
                    %%% Actuator and Sensor
                    thisCGLE.x_a = -1;
                    thisCGLE.var_a = 0.4 * sqrt(2);
                    thisCGLE.x_s = -thisCGLE.x_a;
                    thisCGLE.var_s = thisCGLE.var_a;
                end
            end
        end
        
        function identify(thisCGLE)
            disp(['I am a dynamical SISO complex Ginzburg-Landau system discretised with nx = ',num2str(thisCGLE.nx),' chebshev points'])
        end
        %% Get
        function S_min = Get_RHP_p_z_S_min(thisCGLE)
            [z, p] = zpkdata(thisCGLE.P,'v');
            
            z_vec = z(real(z) > 0);
            p_vec = p(real(p) > 0);
            if isempty(z_vec) || isempty(p_vec)
                S_min = NaN;
            else
                Cj = ones(1,length(z_vec));
                for j = 1:length(z_vec)
                    for k = 1:length(p_vec)
                        Cj(j) = Cj(j) * abs( z_vec(j) + conj(p_vec(k)) ) / abs(z_vec(j) - p_vec(k) );
                    end
                end
                S_min = max(Cj);
            end
        end
        %% Reshape x_a
        function theCGLE = set.x_a(theCGLE,x_a)
            theCGLE.x_a = reshape(x_a,[1,numel(x_a)]);
        end
        %% Reshape x_s
        function theCGLE = set.x_s(theCGLE,x_s)
            theCGLE.x_s = reshape(x_s,[1,numel(x_s)]);
        end
        %% Reshape var_a
        function theCGLE = set.var_a(theCGLE,var_a)
            if  all(var_a > 0) && ~isempty(var_a)
                theCGLE.var_a = reshape(var_a,[1,numel(var_a)]);
            elseif length(var_a) == 1 && (var_a == 0)
                theCGLE.var_a = 0;
            else
                error('Positive actuator variance required. When var_a = 0, then an identical force is applied at each grid point in the flow.')
            end
        end
        %% Reshape var_s
        function theCGLE = set.var_s(theCGLE,var_s)
            if  all(var_s > 0) && ~isempty(var_s)
                theCGLE.var_s = reshape(var_s,[1,numel(var_s)]);
            elseif length(var_s) == 1 && (var_s == 0)
                theCGLE.var_s = 0;
            else
                error('Positive actuator variance required. When var_a = 0, then an identical force is applied at each grid point in the flow.')
            end
        end
        %%
        function impulse(ThisSystem,tvm,nt)
            % dt - time step
            % tvm - max time
            % tvm - time vector, if dt not given
            if nargin == 2
                impulse(ThisSystem.P,tvm)
            elseif nargin == 3
                impulse(ThisSystem.P,linspace(0,tvm,nt))
            else
                impulse(ThisSystem.P)
            end
        end
        
        function bode(ThisSystem)
            bode(ThisSystem.P)
        end
        function pzplot(ThisSystem)
            pzplot(ThisSystem.P)
        end
        
        %% Set B
        function B = get.B(theCGLE)
            if theCGLE.var_a ~= 0
                B = zeros(length(theCGLE.xgrid), length(theCGLE.x_a));
                nx = length(theCGLE.x_a);
                nv = length(theCGLE.var_a);
                for i = 1:nx
                    j = rem(i,nv); if j == 0, j = nv; end
                    B(:,i) = exp( -((theCGLE.xgrid - theCGLE.x_a(i)) / theCGLE.var_a(j)) .^ 2);
                end
            elseif theCGLE.var_a == 0
                B = eye(size(theCGLE.A));
            end
            
        end
        %% Set C
        function C = get.C(theCGLE)
            if theCGLE.var_s ~= 0
                C = zeros(length(theCGLE.xgrid), length(theCGLE.x_s));
                nx = length(theCGLE.x_s);
                nv = length(theCGLE.var_s);
                for i = 1:nx
                    C(:,i) = exp( -((theCGLE.xgrid - theCGLE.x_s(i)) / theCGLE.var_s(rem(nx,nv) + 1)) .^ 2);
                end
                C = theCGLE.Q * exp( -((theCGLE.xgrid - theCGLE.x_s) / theCGLE.var_s ) .^2 );
                C = C';
            elseif theCGLE.var_s == 0
                C = eye(size(theCGLE.A));
                C = C';
            end
        end
        %% Get Dynamic model
        function P = get.P(theCGLE)
            P = ss(theCGLE.A,theCGLE.B,theCGLE.C,0);
        end
        %% Restricted R
        function theCGLE = set.R(theCGLE,R)
            if  any(R > 0)
                theCGLE.R = R;
            else
                error('R cannot be negative')
            end
        end
        %% Restricted beta
        function theCGLE = set.beta(theCGLE,beta)
            if  any(beta > 0)
                theCGLE.beta = beta;
            else
                error('beta cannot be negative')
            end
        end
        %% Restricted Vp05
        function theCGLE = set.Vp05(theCGLE,Vp05)
            if  any(Vp05 > 0)
                theCGLE.Vp05 = Vp05;
            else
                error('Vp05 cannot be negative')
            end
        end
        %% Set gammaIO
        function GammaIO = get.GammaIO(theCGLE)
            B1 = [sqrt(inv(theCGLE.Q)), zeros(theCGLE.nx,1)];
            C1 = [sqrt(theCGLE.beta.^2 * theCGLE.Q); zeros(1,theCGLE.nx)];
            
            [X,~,~] = care(theCGLE.A,theCGLE.B,C1'*C1,theCGLE.R);
            [Y,~,~] = care(theCGLE.A',theCGLE.C',B1*B1',theCGLE.Vp05^2);
            
            GammaIO = trace(C1 * Y * C1') + trace((theCGLE.Vp05^2) \ theCGLE.C * Y*X*Y * theCGLE.C');
        end
        %% Set gammaOE
        function GammaOE = get.GammaOE(theCGLE)
            B1 = [inv(sqrt(theCGLE.Q)), zeros(theCGLE.nx,1)];
            C1 =  sqrt(theCGLE.Q);
            [Y,~,~] = care(theCGLE.A',theCGLE.C',B1*B1',theCGLE.Vp05^2);
            GammaOE = trace(C1 * Y * C1');
        end
        %% Set gammaFI
        function GammaFI = get.GammaFI(theCGLE)
            C1 = sqrt(theCGLE.beta^2 * theCGLE.Q);
            B1 = inv(sqrt(theCGLE.Q));
            [X,~,~] = care(theCGLE.A,theCGLE.B,C1'*C1,theCGLE.R);
            GammaFI = trace(B1' * X * B1);
        end
    end
    
end
